<!DOCTYPE html>
<html>
<head>
	<title>STRING OPERATION</title>
</head>

<body><center>
	<h1>
		STRING OPERATIONS USING
		SWITCH CASE 
	</h1>

	<h3>Option-1 = Reversing string</h3>
	<h3>Option-2 = Finding length of string</h3>
	<h3>Option-3 = Substring operations</h3>
	<h3>Option-4 = Converting to uppercase</h3>
	<h3>Option-5 = Converting to lowercase</h3>
	<h3>Option-6 = Counting number of words</h3>
	
	<form method="post">
		<table border="0">
			<tr>
				<!-- Taking value 1 in an text box -->
				<td> <input type="text" name="num1"
					value="" placeholder="Enter string"/>
				</td>
			</tr>

			<tr>
				<!-- Taking option in an text box -->
				<td> <input type="text" name="option" value=""
					placeholder="Enter option 1-6 only"/>
				</td>
			</tr>

			<tr>
				<td> <input type="submit" name="submit"
					value="Submit"/>
				</td>
			</tr>
		</table>
	</form>
</center>

<?php

// Checking submit condition
if(isset($_POST['submit'])) {

	// Taking first number from the
	// form data to variable 'a'
	$a = $_POST['num1'];

	// Taking option from the form
	// data to a variable 'ch'
	$ch = $_POST['option'];

	switch($ch) {
		case 1:

			// Execute addition operation
			// when option 1 is given
			$str = $a;
			echo strrev($str); 
			break;

		case 2:

			// Executing subtraction operation
			// when option 2 is given
			$str = $a;
			echo strlen($str);

		case 3:

			// Executing multiplication operation
			// when option 3 is given
			function Substring($str){
    		$len = strlen($str);
    		echo substr($str, 8), "<br>";
    		echo substr($str, 5, $len), "<br>";
   			 echo substr($str, -5, 10), "<br>";
		   	  echo substr($str,-8, -5), "<br>";
				}
  
				// Driver Code
				$str=$a;
				Substring($str);

		case 4:

			// Executing division operation
			// when option 4 is given
			$str=$a;
			$resStr = strtoupper($str);
			echo ($resStr);
			break;
		case 5:

			// Executing division operation
			// when option 4 is given
			$str=$a;
			$resStr = strtolower($str);
			echo ($resStr);
			break;
	    case 6:

			// Executing division operation
			// when option 4 is given
			$str=$a;
			$resStr = str_word_count($str);
			echo ($resStr);
			break;

		default:

			// When 1 to 6 option is not given
			// then this condition is executed
			echo ("invalid option\n");
	}
	
	return 0;
}
?>
</body>
</html>
