<html>
<head>
<title>BILL READING</title>
</head>
<body>
<!--- input form with text box --->
<form method="post" action="">
<label>Previous reading</label>
<input type="text" name="num1" value="" />
<label>Current  reading</label>
<input type="text" name="num2" value="" />
<input type="submit" name="submit" value="Submit" />

</form>
<?php
	if($_POST){

		$prev=$_POST['num1'];
		$cur=$_POST['num2'];
		$unit=$cur-$prev;
		$total=0;
		if($unit<=100){
			$total=$unit*3;
		}
		else if($unit<=200){
			$total=(100*3)+($unit-100)*4;
		}
		else if($unit<=300){
			$total=(100*3)+(100*4)+($unit-200)*5;
		}
		else if($unit>300){
			$total=(100*3)+(100*4)+(100*5)+($unit-300)*6;
		}
		echo'PREVIOUS READING:'.$prev."<br>";
		echo'CURRENT READING:'.$cur."<br>";
		echo'UNITS:'.$unit."<br>";
		echo'TOTAL PAYABLE AMOUNT:'.$total."<br>";

}
?>
</body></html>