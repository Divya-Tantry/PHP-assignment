<html>
<body>
  <form method="post" action="item.php">
    <label>Enter the item names</label>
    <input type="text" name="names" required=""><br>
    <br><label>Enter the item price</label>
    <input type="text" name="price" required="">
  <br><input type="submit" name="submit" value="Submit" />
<input type="reset" name="reset" value="Reset" />

  </form>
</body>
</html>
