<html>
<head>
<title>Square root of a number using form</title>
</head>
<body>
<!--- input form with text box --->
<form method="post" action="">
<label>Enter a number</label>
<input type="text" name="num" value="" />
<input type="submit" name="submit" value="Submit" />

</form>
<?php
if(isset($_POST['submit'])) {
//storing the number in a variable $input
$num = $_POST['num'];
//storing the square root of the number in a variable $ans
$revnum=0;  
while ($num>=1)  
{  
$rem = $num % 10;  
$revnum = ($revnum * 10) + $rem;  
$num = ($num / 10);   
}  
//printing the result
echo 'The reverse number of :='.$revnum."<br>";
}
?>
<?php  
if(isset($_POST['submit'])) 
//storing the number in a variable $input
$num = $_POST['num'];  
$sum=0; $rem=0;  
  for ($i =0; $i<=strlen($num);$i++)  
 {  
  $rem=$num%10;  
   $sum = $sum + $rem;  
   $num=$num/10;  
  }  
 echo "Sum of digits is $sum" ."<br>";  

 ?> 
 
<?php   
    if($_POST)  
    {  
        //get the value from form  
        $num = $_POST['num'];  
        //reversing the number  
        $revnum = strrev($num);  
          
        //checking if the number and reverse is equal  
        if($num == $revnum){  
            echo "The number $num is Palindrome";     
        }else{  
            echo "The number $num is not a Palindrome";   
        }  
}     
      ?>  

</body>
</html>


