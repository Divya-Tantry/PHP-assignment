<?php

if($_POST['submit']){
	$names=$_POST['names'];
	$price=$_POST['price'];

	$nme=explode(',',$names);
	$x=count($nme);
	$prc=explode(',',$price);

	echo'<body><table height="100" width="200" cellspacing="30" border="5"><tr><th>ITEM NAME</th><th>ITEM PRICE</th>' ;
	for($i=0;$i<$x;$i++){
		echo"<tr><td>{$nme[$i]}</td><td>{$prc[$i]}</td></tr>";
	}
	echo"</tr>";
	echo"</table>";
	$total=0;
	for($i=0;$i<$x;$i++){
		$total=$total+$prc[$i];
	}
	echo'Total amount is:'.$total."<br>";
	$mx=max($prc);
	$ky=array_search($mx,$prc);
	echo'Costliest item:'.$nme[$ky]."<br>";
	$mn=min($prc);
	$key=array_search($mn,$prc);
	echo'Chepest item:'.$nme[$key]."<br>";

}

?>
<form metod="post" action="p11.php">
	 <input type="submit" name="submit" value="Back" />
	</form>