<!DOCTYPE html>
<html>
<style>
p {
color:white;
font-size:90px;
position: relative;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
}
body{background-color:black;}
</style>
<p> <?php 
date_default_timezone_set('Asia/Kolkata');
$date = date('d-m-y h:i:sa');
echo "Today is " . date("l")."<br>";
echo $date;
?> </p>
</head>
<body>
</body>
</html>

